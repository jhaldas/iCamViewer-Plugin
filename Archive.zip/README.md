# iCamViewer BuildFire.js Plugin
This is a plugin made with the BuildFire SDK.


## Installation
1) Follow the instructions for how to set up the SDK at https://sdk.buildfire.com/docs/how-to-setup-your-development-environment
2) Clone iCamViewer-Plugin repository to plugins folder.
