# defaultPluginTemplate
Default simple plugin template 
